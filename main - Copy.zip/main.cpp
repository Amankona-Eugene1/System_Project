#include <iostream>
#include <iomanip>

using namespace std;
/*
GP - Grade Point
The Grade Point is the number of (grade) points earned by a student for each course completed in a semester
GPA - Grade Point Average
GPA is used to find result of all grades achieved throughout your course for a semester.
CGPA - Cumulative Point Average
CGPA is the average of Grade Points obtained for all courses completed up to a specified or given academic semester.*/



// Structure to store course information
struct Course {
    string courseName;
    int credits;
    int grade;
};

// Function to calculate GPA
float calculateCGPA(int grade) {
    if (grade >= 80) return 4.0;
    else if (grade >= 75) return 3.50;
    else if (grade >= 70) return 3.0;
    else if (grade >= 65) return 2.50;
    else if (grade >= 60) return 2.0;
    else if (grade >= 55) return 1.50;
    else if (grade >= 50) return 1.0;
    else if (grade >= 45) return 0.50;
    else return 0.0;
}

int main() {
    int numCourses;
    cout << "                                       ======================================" << endl;
    cout << "                                       ---------- CGPA Calculator ---------- " << endl;
    cout << "                                       ======================================" << endl << endl;
    cout << "                                       Enter the number of courses: ";
    cin >> numCourses;
    cout << endl;

    Course courses[numCourses];

    // Input course details
    for (int i = 0; i < numCourses; i++) {
        cout << "                                       Enter details for Course " << i + 1 << ":" << endl;
        cout << "                                       Course Name: ";
        cin >> courses[i].courseName;
        cout << "                                       Credits: ";
        cin >> courses[i].credits;
        cout << "                                       Grade (out of 100): ";
        cin >> courses[i].grade;
        cout << endl;
    }

    float totalCredits = 0;
    float totalGradePoints = 0;

    // Calculate total credits and grade points
    for (int i = 0; i < numCourses; i++) {
        totalCredits += courses[i].credits;
        totalGradePoints += courses[i].credits * calculateCGPA(courses[i].grade);

        cout << left << setw(15) << "                                       " << "COURSE NAME" <<"     " << "CREDIT" << "     " << "TOTAL" << endl;
        cout << "                                       ";
        cout << left << setw(15) << courses[i].courseName <<"     ";
        cout << left << setw(15) << courses[i].credits << "     ";
        cout << left << setw(15) << courses[i].grade << endl;
    }


    // Calculate CGPA
    float CGPA = totalGradePoints / totalCredits;

    cout << fixed << setprecision(2);
    cout << endl;
    cout << "                                       CGPA for your courses: " << CGPA << endl;
    cout << "                                    ======================================";
    // CGPA calculation
    // You can add more semesters' GPA and totalCredits to calculate CGPA over multiple semesters

    return 0;
}
